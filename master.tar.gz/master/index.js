require('canvas')
console.log("Requiring canvas doesn't throw an error anymore, congrats")
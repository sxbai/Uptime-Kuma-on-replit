# 使用说明
欢迎Fork本项目，Uptime-Kuma-on-replit

一键搭建脚本 (环境选择`Bash` 或 `Blank Repl`)
```
bash <(curl -s https://raw.githubusercontent.com/sxbai/Uptime-Kuma-on-replit/master/install.sh)
```
